# Práctica de Laboratorio #1

  Este fichero está escrito en lenguaje Markdown

  1. Modifique este fichero para que contenga:

  * Adahi Oval Afonso
  * alu0101242071@ull.edu.es
  * Jueves 7/10/2021, 12:00 - 13:00, PE102


  2. Guarde los cambios en la copia local, en una confirmación "Modificado nombre".
