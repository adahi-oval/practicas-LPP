Adahi Oval Afonso.
Práctica Número 3: Reorganización de ramas con git. Gestores de intérpretes de Ruby.
