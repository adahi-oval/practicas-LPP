RSpec.describe Granja do

  context "Funciones Programación Funcional" do
    let(:ave1) {Granja::Ave.new("id",700,"sex",50,"beak","feet","move")}
    let(:ave2) {Granja::Ave.new("id",25,"sex",40,"beak","feet","move")}
    let(:ave3) {Granja::Ave.new("id",800,"sex",250,"beak","feet","move")}
    let(:ave4) {Granja::Ave.new("id",400,"sex",125,"beak","feet","move")}
    let(:avicola) {Granja::Avicola.new(1,"name",:avicola,"desc",:pollos,:huevos,2,12,23,[ave1],Granja::Funcion::JAULA)}
    let(:avicolaventa) {Granja::Avicola.new(1,"name",:avicola,"desc",:pollos,:sacrificio,2,12,23,[ave1,ave2],Granja::Funcion::CAMPO)}
    let(:avicola3) {Granja::Avicola.new(1,"name",:avicola,"desc",:pollos,:sacrificio,2,12,23,[ave3,ave4],Granja::Funcion::CAMPO)}

    describe "Funcionalidades" do
      it "Funcionalidad para calcular el bienestar animal" do
        bienestar = (ave1.weight/ave1.age)/avicola.list.length
        expect(Granja::Funcion.bienestar(avicola)).to eq(bienestar)
      end

      it "Funcionalidad para calcular el beneficio neto" do
        net_benefit = (ave1.weight/avicolaventa.precioventa + ave2.weight/avicolaventa.precioventa)/avicolaventa.list.length
        expect(Granja::Funcion.net_benefit(avicolaventa)).to eq(net_benefit)
      end

      it "Funcionalidad para calcular el indice de productividad" do
        bienestar = (ave1.weight/ave1.age + ave2.weight/ave2.age)/avicolaventa.list.length
        net_benefit = (ave1.weight/avicolaventa.precioventa + ave2.weight/avicolaventa.precioventa)/avicolaventa.list.length
        case
        when bienestar <= 20
          bienestar = 1
        
        when bienestar === (21...79)
          bienestar = 2
        
        else
          bienestar = 3
        end

        case
        when net_benefit < 10 
          net_benefit = 1
        
        when net_benefit === (10...50)
          net_benefit = 2
    
        else
          net_benefit = 3
        end

        prod_index = (bienestar + net_benefit) / 2
        expect(Granja::Funcion.prod_index(avicolaventa)).to eq(prod_index)
      end
    
    end

    describe "Tests" do
    
      it "Granja con mayor prod_index" do
        cooperativa = [avicola, avicolaventa, avicola3]
        max = cooperativa[0]
        cooperativa.each {|i| if Granja::Funcion.prod_index(max) < Granja::Funcion.prod_index(i); max = i end}
        expect(max).to be(avicola)
      end

      it "Subir precio segun prod_index" do
        cooperativa = [avicola, avicolaventa, avicola3]
        max = cooperativa[0]
        cooperativa.each {|i| if Granja::Funcion.prod_index(max) < Granja::Funcion.prod_index(i); max = i end}
        ratio = max.precioventa/max.precio
        #cooperativa.each {|i| if i != max; precio_original = i.precioventa; i.precioventa += precio_original*ratio; expect(i.precioventa > precio_original).to be true end}
        cooperativa.each do |farm|
          if farm != max
            precio_original = farm.precioventa
            farm.precioventa += precio_original*ratio
            expect(farm.precioventa > precio_original).to be true
          end
        end
      end
    end

  end

end