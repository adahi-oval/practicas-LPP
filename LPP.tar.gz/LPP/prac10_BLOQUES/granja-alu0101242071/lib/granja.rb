# frozen_string_literal: true
require_relative "granja/granja_animal.rb"
require_relative "granja/granja_ave.rb"

require_relative "granja/version"

module Granja
  class Error < StandardError; end
  # @author Adahi Oval
  # Añadido comentario
  module Funcion
  
    ESTABLO = :establo
    CAMPO = :campo
    JAULA = :jaula

    def care(value,list)
      list.collect {|item| item+value}
    end

    def repro(list)
      aux = []
      list.collect do
        |item|
        if item.age>730
          aux << item
        end
      end
      return aux
    end

    def self.conditional(condition, verdadero, falso)
      (lambda {|condition,verdadero,falso| if condition; verdadero else falso end}).call(condition,verdadero,falso)
    end

    def self.bienestar(avicola)
      aux = 0
      avicola.list.each {|i| aux += conditional(CAMPO,i.weight/i.age,(i.weight/i.age)/2)}
      return aux / avicola.list.length
    end
  
    def self.net_benefit(avicola)
      aux = 0
      avicola.list.each {|i| aux += conditional(avicola.destino == :sacrificio,i.weight/avicola.precioventa,i.age/avicola.precioventa)}
      return aux / avicola.list.length
    end

    def self.bienestar_index(bienestar)
      (lambda {|bienestar| if bienestar <=20; 1 elsif (21...79) === bienestar; 2 else bienestar >=80; 3 end}).call(bienestar)
    end

    def self.benefit_index(benefit)
      (lambda {|benefit| if benefit < 10; 1 elsif (10...50) === benefit; 2 else benefit > 50; 3 end}).call(benefit)
    end

    def self.prod_index(avicola)
      bienestar = bienestar_index(bienestar(avicola))
      net_benefit = benefit_index(net_benefit(avicola))
      return (bienestar+net_benefit) / 2
    end

  end

  # @author Adahi Oval
  class Datos
    attr_reader :id,:name,:type,:desc
    # Crea el objeto Datos
    # @param id,name,type,desc son los atributos que describen a la granja
    def initialize(id,name,type,desc)
      @id = id
      @name = name
      @type = type
      @desc = desc
    end

    def to_s
      "#{@name}:\n  ID: #{@id}\n  Tipo: #{@type}\n  Descripción: #{@desc}"
    end

  end

  class Avicola < Datos
    attr_reader :tipo_ave,:destino,:numero,:precio,:precioventa,:list,:gestion
    include Enumerable
    include Funcion
    def initialize(id,name,type,desc,tipo_ave,destino,numero,precio,precioventa,aves,gestion)
      super(id,name,type,desc)
      @tipo_ave = tipo_ave
      @destino = destino
      @numero = numero
      @precio = precio
      @precioventa = precioventa
      @list = aves
      @gestion = gestion
    end

    def to_s
      "#{@name}:\n  ID: #{@id}\n  Tipo: #{@type}\n  Descripción: #{@desc}\n  Tipo de Aves: #{@tipo_ave}\n  Destino: #{@destino}\n  Numero: #{@numero}\n  Precio: #{@precio}\n  Precio de venta: #{@precioventa}\n  Aves: #{@list} Gestion: #{@gestion}"
    end

    def each
      yield @numero
      yield @precio
      yield @precioventa
    end

    def collect
      yield @numero
      yield @precio
      yield @precioventa
    end

  end 

end
