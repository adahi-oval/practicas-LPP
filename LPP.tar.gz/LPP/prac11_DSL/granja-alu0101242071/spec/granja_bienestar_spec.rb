RSpec.describe Granja do

  context "Funciones Programación Funcional" do
    let(:ave1) {Granja::Ave.new("id",700,"sex",500,"beak","feet","move")}
    let(:ave2) {Granja::Ave.new("id",25,"sex",40,"beak","feet","move")}
    let(:ave3) {Granja::Ave.new("id",800,"sex",250,"beak","feet","move")}
    let(:ave4) {Granja::Ave.new("id",400,"sex",125,"beak","feet","move")}
    let(:avicola) {Granja::Avicola.new(1,"name",:avicola,"desc",:pollos,:huevos,2,12,23,[ave1],Granja::Funcion::CAMPO)}
    let(:avicolaventa) {Granja::Avicola.new(1,"name",:avicola,"desc",:pollos,:sacrificio,2,12,15,[ave1,ave2],Granja::Funcion::CAMPO)}
    let(:avicola3) {Granja::Avicola.new(1,"name",:avicola,"desc",:pollos,:sacrificio,2,12,23,[ave3,ave4],Granja::Funcion::CAMPO)}

    describe "Funcionalidades" do
      it "Funcionalidad para calcular el bienestar animal" do
        expect(Granja::Funcion.bienestar(avicola)).to eq(100)
      end

      it "Funcionalidad para calcular el beneficio neto" do
        expect(avicolaventa.destino).to eq(:sacrificio)
        expect(Granja::Funcion.net_benefit(avicolaventa)).to eq(25)
      end

      it "Funcionalidad para calcular el indice de productividad" do
        expect(Granja::Funcion.prod_index(avicolaventa)).to eq(2)
      end
    
    end

    describe "Tests" do
    
      it "Granja con mayor prod_index" do
        cooperativa = [avicola, avicolaventa, avicola3]
        max = cooperativa[0]
        cooperativa.each {|i| if Granja::Funcion.prod_index(max) < Granja::Funcion.prod_index(i); max = i end}
        expect(max).to be(avicola)
      end

      it "Subir precio segun prod_index" do
        cooperativa = [avicola, avicolaventa, avicola3]
        max = cooperativa[0]
        cooperativa.each {|i| if Granja::Funcion.prod_index(max) < Granja::Funcion.prod_index(i); max = i end}
        ratio = max.precioventa/max.precio
        #cooperativa.each {|i| if i != max; precio_original = i.precioventa; i.precioventa += precio_original*ratio; expect(i.precioventa > precio_original).to be true end}
        cooperativa.each do |farm|
          if farm != max
            precio_original = farm.precioventa
            farm.precioventa += precio_original*ratio
            expect(farm.precioventa > precio_original).to be true
          end
        end
      end
    end

  end

end
