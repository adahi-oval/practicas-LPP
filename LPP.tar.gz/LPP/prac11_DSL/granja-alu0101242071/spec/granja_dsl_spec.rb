RSpec.describe Granja do

  context "Lenguaje de Dominio específico - DSL para los datos de una granja" do
    context "Granja::DSLGranja" do
      context "Atributos de la clase DSLGranja" do
        granja_1 = Granja::DSLGranja.new(12345) do
          datos "Pollos hermanos",
                :descripcion => "PyME - Pequeña y mediana empresa",
                :tipo => :pollos
          ejemplar "Manolo",
                    :edad => 365,
                    :peso => 700.2,
                    :precio_compra => 4.25,
                    :precio_venta => 4.75,
                    :destino => :sacrificio
          ejemplar "Manolete",
                    :edad => 3652,
                    :peso => 700.22,
                    :precio_compra => 4.252,
                    :precio_venta => 4.752,
                    :destino => :sacrificio
        end
        
      
        it "Tiene una clase para almacenar los datos de la granja" do
          expect(Granja::DSLGranja).not_to be nil
          expect(Granja::DSLGranja::DSLAnimal).not_to be nil
        end

        it "Tiene un método para los datos" do
          expect(granja_1.id).to eq(12345)
          expect(granja_1.name).to eq("Pollos hermanos")
          expect(granja_1.desc).to eq("PyME - Pequeña y mediana empresa")
          expect(granja_1.tipo_ave).to eq(:pollos)
        end

        it "Tiene un método para los ejemplares" do
          expect(granja_1.animales).not_to be nil
          expect(granja_1.animales.length).to eq(2)
          expect(granja_1.animales[0].id_animal).to eq("Manolo")
          expect(granja_1.animales[0].edad).to eq(365)
          expect(granja_1.animales[0].peso).to eq(700.2)
          expect(granja_1.animales[0].precio_compra).to eq(4.25)
          expect(granja_1.animales[0].precio_venta).to eq(4.75)
          expect(granja_1.animales[0].destino).to eq(:sacrificio)
          expect(granja_1.animales[1].id_animal).to eq("Manolete")
          expect(granja_1.animales[1].edad).to eq(3652)
          expect(granja_1.animales[1].peso).to eq(700.22)
          expect(granja_1.animales[1].precio_compra).to eq(4.252)
          expect(granja_1.animales[1].precio_venta).to eq(4.752)
        end

        it "Se obtiene una cadena con la información de la granja correctamente formateada" do
          expect(granja_1.to_s).to eq("Pollos hermanos\nDesc: PyME - Pequeña y mediana empresa\nTipo: pollos\nEjemplares:\n\tManolo(365 días, 700.2 gramos, 4.25 precio de compra, 4.75 precio de venta)\n\tManolete(3652 días, 700.22 gramos, 4.252 precio de compra, 4.752 precio de venta)")
        end

      end
    end
  end

  context "Lenguaje de Dominio específico - DSL para las funcionalidades de la granja" do
    context "Granja::DSLFuncionalidad" do
      context "Atributos de la clase DSLFuncionalidad" do

        ave1 = Granja::Ave.new("id",700,"sex",500,"beak","feet","move")
        ave2 = Granja::Ave.new("id",800,"sex",250,"beak","feet","move")
        ave3 = Granja::Ave.new("id",1000,"sex",1250,"beak","feet","move")
        ave4 = Granja::Ave.new("id",1000,"sex",25,"beak","feet","move")
        ave5 = Granja::Ave.new("id",1000,"sex",25,"beak","feet","move")
        granja_1 = Granja::Avicola.new(1,"name",:avicola,"desc",:pollos,:sacrificio,2,12,23,[ave1],Granja::Funcion::CAMPO)
        granja_2 = Granja::Avicola.new(1,"name",:avicola,"desc",:pollos,:sacrificio,2,12,23,[ave1,ave2],Granja::Funcion::CAMPO)
        granja_3 = Granja::Avicola.new(1,"name",:avicola,"desc",:pollos,:sacrificio,2,20,1,[ave3,ave4,ave5],Granja::Funcion::CAMPO)

        funciondsl = Granja::DSLFuncionalidad.new(12345) do
          beneficio       granja_1
          bienestar       granja_1, :condiciones => :campo
          productividad   granja_1, :condiciones => :campo
        end

        funciondsl2 = Granja::DSLFuncionalidad.new(12345) do
          beneficio       granja_2
          bienestar       granja_2, :condiciones => :jaula
          productividad   granja_2, :condiciones => :jaula
        end

        funciondsl3 = Granja::DSLFuncionalidad.new(12345) do
          beneficio       granja_3
          bienestar       granja_3, :condiciones => :jaula
          productividad   granja_3, :condiciones => :jaula
        end

        it "Tiene una clase para almacenar las funcionalidades de la granja" do
          expect(Granja::DSLFuncionalidad).not_to be nil
        end

        it "Tiene un método para calcular el beneficio de una granja" do
          expect(Granja::DSLFuncionalidad.method_defined? :beneficio).to be true
          expect(funciondsl.beneficios).to eq(192)
          expect(funciondsl2.beneficios).to eq(192)
          expect(funciondsl3.beneficios).to eq(5)
        end

        it "Tiene un método para calcular el bienestar de una granja" do
          expect(Granja::DSLFuncionalidad.method_defined? :bienestar).to be true
          expect(funciondsl.bienestar_animal).to eq(100)
          expect(funciondsl2.bienestar_animal).to eq(36)
          expect(funciondsl3.bienestar_animal).to eq(17)
        end

        it "Tiene un método para calcular el indice de productividad de una granja" do
          expect(Granja::DSLFuncionalidad.method_defined? :prod_index).to be true
          expect(funciondsl.prod_index).to eq(3)
          expect(funciondsl2.prod_index).to eq(2)
          expect(funciondsl3.prod_index).to eq(1)
        end

        it "Se obtiene una cadena con la información correctamente formateada" do
          expect(funciondsl3.to_s).to eq("12345:\n\tBeneficios: 5%\n\tBienestar: 17\n\tÍndice de productividad: 1")
          expect(funciondsl2.to_s).to eq("12345:\n\tBeneficios: 192%\n\tBienestar: 36\n\tÍndice de productividad: 2")
          expect(funciondsl.to_s).to eq("12345:\n\tBeneficios: 192%\n\tBienestar: 100\n\tÍndice de productividad: 3")
        end

      end
    end
  end

end