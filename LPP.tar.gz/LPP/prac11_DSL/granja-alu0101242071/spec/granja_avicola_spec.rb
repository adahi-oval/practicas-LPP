RSpec.describe Granja do

  context "Herencia de la clase Avícola" do
    let(:avicola) {Granja::Avicola.new(1,"name",:avicola,"desc",:pollos,:huevos,2,12,23,[1,2,3],Granja::Funcion::JAULA)}

    it "Se espera que una instancia de la clase Avicola sea una granja Avicola" do
      expect(avicola.is_a?(Granja::Avicola)).to be true
    end

    it "Se espera que una instancia de la clase Avicola sea un Dato" do 
      expect(avicola.is_a?(Granja::Datos)).to be true
    end

    it "Se espera que una instancia de la clase Avicola sea un Object" do 
      expect(avicola.is_a?(Object)).to be true
    end

    it "Se espera que una instancia de la clase Avicola sea un BasicObject" do 
      expect(avicola.is_a?(BasicObject)).to be true
    end

    it "No se espera que una instancia de la clase Avicola sea un Animal" do 
      expect(avicola.is_a?(Granja::Animal)).to be false
    end

    it "No se espera que una instancia de la clase Avicola sea un Ave" do 
      expect(avicola.is_a?(Granja::Ave)).to be false
    end

    it "Se espera que una instancia de la clase Avicola sea Enumerable" do 
      expect(avicola.is_a?(Enumerable)).to be true
    end

  end

  context "Atributos de la clase Avicola" do
    let(:avicola) {Granja::Avicola.new(1,"name",:avicola,"desc",:pollos,:huevos,2,12,23,[1,2,3],Granja::Funcion::JAULA)}

    it "Tiene una clase para almacenar los datos de la granja" do
      expect(Granja::Datos).not_to be(nil)
    end

    it "Tiene un atributo para el tipo de aves (gansos, pollos, patos, pavos)" do
      expect(avicola.tipo_ave).not_to be(nil)
    end

    it "Tiene un atributo para el destino de los animales (huevos, sacrificio)" do
      expect(avicola.destino).not_to be(nil)
    end

    it "Tiene un atributo para el numero de aves" do
      expect(avicola.numero).not_to be(nil)
    end

    it "Tiene un atributo para el precio unitario de las aves" do
      expect(avicola.precio).not_to be(nil)
    end

    it "Tiene un atributo para el precio de venta de las aves" do
      expect(avicola.precioventa).not_to be(nil)
    end

    it "Tiene un atributo para almacenar las aves de la granja" do
      expect(avicola.list).not_to be(nil)
    end

  end

  context "Funcionalidades añadidas por avicola" do
    let(:avicola) {Granja::Avicola.new(1,"name",:avicola,"desc",:pollos,:huevos,2,12,23,[1,2,3],Granja::Funcion::JAULA)}
    let(:ave1) {Granja::Ave.new("id",800,"sex",233,"beak","feet","move")}
    let(:ave2) {Granja::Ave.new("id",700,"sex",533,"beak","feet","move")}
  
    it "Cuidados funciona correctamente" do
      expect(avicola.care(8,[2,3,10]) == [10,11,18]).to be true
    end

    it "Repro funciona correctamente" do
      expect(avicola.repro([ave1,ave2]) == [ave1]).to be true
    end

  end 

end