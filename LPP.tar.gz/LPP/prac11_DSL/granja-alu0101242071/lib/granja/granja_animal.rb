module Granja

    # @author Adahi Oval
    class Animal
      include Comparable
      attr_reader :id, :age, :sex, :weight
      def initialize(id,age,sex,weight)
        @id = id
        @age = age
        @sex = sex
        @weight = weight
        if defined?(@@number_of_animals)
          @@number_of_animals += 1
        else
          @@number_of_animals = 1
        end
      end
  
      def to_s
        "#{@id}:\n  Edad: #{@age}\n  Sexo: #{@sex}\n  Peso: #{@weight}"
      end
  
      def count
         @@number_of_animals
      end

      def <=>(other)
        return nil unless other.is_a?(Animal)
        @weight <=> other.weight
      end

    end
  

end