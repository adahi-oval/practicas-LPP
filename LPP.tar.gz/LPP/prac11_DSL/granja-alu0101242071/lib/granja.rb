# frozen_string_literal: true
require_relative "granja/granja_animal.rb"
require_relative "granja/granja_ave.rb"

require_relative "granja/version"

module Granja
  class Error < StandardError; end
  # @author Adahi Oval
  # Añadido comentario
  module Funcion
    
    ESTABLO = :establo
    CAMPO = :campo
    JAULA = :jaula
    # @note Metodo para los cuidados de los animales
    # @param value,list los parámetros para la medicina de los animales y la lista a la que añadir el valor
    def care(value,list)
      list.collect {|item| item+value}
    end

    # @note Metodo para la reproduccion de los animales
    def repro(list)
      aux = []
      list.collect do
        |item|
        if item.age>730
          aux << item
        end
      end
      return aux
    end

    # @note Metodo para calcular el bienestar animal en una granja avicola segun las condiciones
    # @param avicola,condiciones son la granja y las condiciones de la misma para calcular el bienestar
    def self.bienestar(avicola, condiciones)
      ratio_peso_edad = []
      avicola.list.each {|animal| ratio_peso_edad << animal.weight.to_f/animal.age}
      max_ratio = ratio_peso_edad.max
      media_ratio = ratio_peso_edad.sum / ratio_peso_edad.size

      if (condiciones == :campo)
        return ((media_ratio / max_ratio) * 100).round(0)
      else
        return ((media_ratio / max_ratio) * 50).round(0)
      end
    end
  
    # @note Metodo para calcular el porcentaje de beneficios de una granja
    # @param granja es la granja sobre la que se calculan los beneficios
    def self.net_benefit(granja)
      total_venta = 0
      total_compra = 0
      if granja.destino == :sacrificio
        granja.list.each{
          |animal| 
          total_venta += animal.weight
          total_compra += animal.weight
        }
        media_venta = total_venta * granja.precioventa
        media_compra = total_compra * granja.precio
        beneficio = ((media_venta.to_f/media_compra)*100).round(0)
        return beneficio
      else
        granja.list.each{
          |animal| 
          total_venta += animal.age.to_f/granja.precioventa
          total_compra += animal.age.to_f/granja.precio
        }
        media_venta = total_venta / granja.list.length
        media_compra = total_compra / granja.list.length
        beneficio = ((media_venta/media_compra)*100).round(0)
        return beneficio
      end
    end

    # @note Metodo para calcular el índice según el intervalo en el que caiga el bienestar animal
    def self.bienestar_index(bienestar)
      (lambda {|bienestar| if bienestar <=20; 1 elsif (21...79) === bienestar; 2 else bienestar >=80; 3 end}).call(bienestar)
    end

    # @note Metodo para calcular el índice según el intervalo en el que caigan los beneficios
    def self.benefit_index(benefit)
      (lambda {|benefit| if benefit < 10; 1 elsif (10...50) === benefit; 2 else benefit > 50; 3 end}).call(benefit)
    end

    # @note Metodo para calcular el índice de productividad según los índices de los otros dos métodos
    # @param avicola,condiciones Avicola es la granja sobre la que se calcula el índice y condiciones las condiciones de la granja para calcular el bienestar
    def self.prod_index(avicola, condiciones)
      bienestar = bienestar_index(bienestar(avicola, condiciones))
      net_benefit = benefit_index(net_benefit(avicola))
      return ((bienestar+net_benefit) / 2).round(0)
    end

  end

  # @author Adahi Oval
  class Datos
    attr_reader :id,:name,:type,:desc
    # Crea el objeto Datos
    # @param id,name,type,desc son los atributos que describen a la granja
    def initialize(id,name,type,desc)
      @id = id
      @name = name
      @type = type
      @desc = desc
    end

    def to_s
      "#{@name}:\n  ID: #{@id}\n  Tipo: #{@type}\n  Descripción: #{@desc}"
    end

  end

  class Avicola < Datos
    attr_reader :tipo_ave,:destino,:numero,:precio,:precioventa,:list,:gestion
    include Enumerable
    include Funcion
    def initialize(id,name,type,desc,tipo_ave,destino,numero,precio,precioventa,aves,gestion)
      super(id,name,type,desc)
      @tipo_ave = tipo_ave
      @destino = destino
      @numero = numero
      @precio = precio
      @precioventa = precioventa
      @list = aves
      @gestion = gestion
    end

    def to_s
      "#{@name}:\n  ID: #{@id}\n  Tipo: #{@type}\n  Descripción: #{@desc}\n  Tipo de Aves: #{@tipo_ave}\n  Destino: #{@destino}\n  Numero: #{@numero}\n  Precio de compra: #{@precio}\n  Precio de venta: #{@precioventa}\n  Aves: #{@list} Gestion: #{@gestion}"
    end

    def each
      yield @numero
      yield @precio
      yield @precioventa
    end

    def collect
      yield @numero
      yield @precio
      yield @precioventa
    end

  end 

  # @author Adahi Oval
  class DSLGranja
    attr_reader :id,:name,:desc,:tipo_ave,:animales
    # @param id,block La id de la granja que se crea y el bloque con las instrucciones para crearlas en DSL
    def initialize(id, &block)
      @id = id
      @name = ""
      @desc = ""
      @tipo_ave = ""
      @animales = []

      if block_given?
        if block.arity == 1
          yield self
        else
          instance_eval(&block)
        end
      end
    end

    def to_s
      output = "#{@name}\nDesc: #{@desc}\nTipo: #{@tipo_ave}\nEjemplares:"
      @animales.each {
        |animal|
        output2 = animal.to_s
        output += output2
      }
      return output
    end
    # @author Adahi Oval
    # @note Clase para los ejemplares de la granja tipo DSLGranja
    class DSLAnimal
      attr_reader :id_animal,:edad,:peso,:precio_compra,:precio_venta,:destino
      def initialize(id_animal,edad,peso,precio_compra,precio_venta,destino)
        @id_animal = id_animal
        @edad = edad
        @peso = peso
        @precio_compra = precio_compra
        @precio_venta = precio_venta
        @destino = destino
      end

      def to_s
        output = "\n\t#{@id_animal}(#{@edad} días, #{@peso} gramos, #{@precio_compra} precio de compra, #{@precio_venta} precio de venta)"
        return output
      end
    end

    # @note Metodo para detectar los datos en DSL y añadirlos a la granja
    def datos(name, options = {})
      @name = "#{name}"
      @desc = "#{options[:descripcion]}" if options[:descripcion]
      @tipo_ave = options[:tipo] if options[:tipo]
    end

    # @note Metodo para detectar los ejemplares en DSL y añadirlos a la granja
    def ejemplar(id_animal, options = {})
      id_animal = "#{id_animal}"
      edad = options[:edad] if options[:edad]
      peso = options[:peso] if options[:peso]
      precio_compra = options[:precio_compra] if options[:precio_compra]
      precio_venta = options[:precio_venta] if options[:precio_venta]
      destino = options[:destino] if options[:destino]
      @animales << DSLAnimal.new(id_animal,edad,peso,precio_compra,precio_venta,destino)
    end

  end

  class DSLFuncionalidad
    attr_reader :id,:beneficios,:bienestar_animal,:prod_index
    # @param id,block La id de la granja que se crea y el bloque con las instrucciones para crearlas en DSL 
    def initialize(id, &block)
      @id = id
      @beneficios = ""
      @bienestar_animal = ""
      @prod_index = ""
      if block_given?
        if block.arity == 1
          yield self
        else
          instance_eval(&block)
        end
      end
    end

    # @note Metodo para obtener los beneficios de la granja en DSL
    def beneficio(granja)
      @beneficios = Granja::Funcion.net_benefit(granja)
    end

    # @note Metodo para obtener el bienestar de la granja en DSL
    def bienestar(granja, options = {})
      @bienestar_animal = Granja::Funcion.bienestar(granja, options[:condiciones]) if options[:condiciones]
    end

    # @note Metodo para obtener el indice de la granja en DSL
    def productividad(granja, options = {})
      @prod_index = Granja::Funcion.prod_index(granja, options[:condiciones]) if options[:condiciones]
    end

    def to_s
      output = "#{@id}:\n\tBeneficios: #{@beneficios}%\n\tBienestar: #{@bienestar_animal}\n\tÍndice de productividad: #{@prod_index}"
    end

  end

end
