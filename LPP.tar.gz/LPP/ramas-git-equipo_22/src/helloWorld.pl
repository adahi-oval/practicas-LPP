write('Hello world!'), nl.
