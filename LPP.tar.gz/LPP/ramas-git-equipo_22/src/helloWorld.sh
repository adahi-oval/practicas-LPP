#! /bin/sh 
#Bourne Shell: 
echo hello, world 
