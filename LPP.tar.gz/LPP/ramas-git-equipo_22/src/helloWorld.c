/* 
 * C (CeeLanguage) (according to KernighanAndRitchie) 
 */
#include <stdio.h> 
#include <stdlib.h> 
int main(void) 
{ 
printf("Hello, world\n"); 
return EXIT_SUCCESS; 
} 
