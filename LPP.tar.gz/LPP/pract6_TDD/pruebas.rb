class Matriz

  attr_reader :rows, :cols, :data
  
  def initialize(data)
    @rows = data.length
    @cols = data[0].length
    @data = data
  end

  def to_s
    return @data.join('')
  end

  def suma(matrix)
    result = Matriz.new(Array.new(self.rows) { Array.new(self.cols, 0) })
    for i in 0..self.rows - 1
      for j in 0..self.rows - 1
        result.data[i][j] = self.data[i][j] + matrix.data[i][j]
      end
    end
    return result
  end

  def producto(num)
    result = Matriz.new(Array.new(self.rows) { Array.new(self.cols, 0) })
    for i in 0..self.rows - 1
      for j in 0..self.rows - 1
        result.data[i][j] = self.data[i][j] * num
      end
    end
    return result
  end

  def traspuesta()
    result = Matriz.new(Array.new(self.rows) { Array.new(self.cols, 0) })
    for i in 0..self.rows - 1
      for j in 0..self.rows - 1
        result.data[i][j] = self.data.transpose[i][j]
      end
    end
    return result
  end

end
