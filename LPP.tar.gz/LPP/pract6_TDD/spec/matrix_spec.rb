require 'matrix'

describe Matriz do
  
  it "Se instancia una matriz con un Array de dos dimensiones data" do
    expect(Matriz.new(Array.new(2, Array.new(2, 0)))).not_to eq(nil)
  end
  
  it "Se debe poder acceder a los atributos(rows, cols, data) con los getters" do
    expect(Matriz.new(Array.new(2, Array.new(2, 0))).rows).to eq(2)
    expect(Matriz.new(Array.new(2, Array.new(2, 0))).cols).to eq(2)
    expect(Matriz.new(Array.new(2, Array.new(2, 0))).data).to eq(Array.new(2, Array.new(2, 0)))  
  end

  it "Se debe poder pasar a string" do
    expect(Matriz.new(Array.new(2, Array.new(2, 0))).to_s).to eq("0 0 0 0")
    expect(Matriz.new(Array.new(2, Array.new(2, 0))).to_s).not_to eq(nil)
    expect(Matriz.new(Array.new(3, Array.new(3, 1))).to_s).to eq("1 1 1 1 1 1 1 1 1")
  end

  it "Se debe poder sumar dos matrices" do
    expect(Matriz.new(Array.new(2, Array.new(2, 1))).suma(Matriz.new(Array.new(2, Array.new(2, 2)))).to_s).to eq(Matriz.new(Array.new(2, Array.new(2, 3))).to_s)
    expect(Matriz.new(Array.new(2, Array.new(2, 1))).suma(Matriz.new(Array.new(2, Array.new(2, 2)))).to_s).not_to eq(nil)
    expect(Matriz.new(Array.new(3, Array.new(3, 3))).suma(Matriz.new(Array.new(3, Array.new(3, 1)))).to_s).to eq(Matriz.new(Array.new(3, Array.new(3,4))).to_s)
  end

  it "Se debe poder multiplicar por un escalar" do
    expect(Matriz.new(Array.new(2, Array.new(2, 1))).escalar(4).to_s).to eq(Matriz.new(Array.new(2, Array.new(2, 4))).to_s)
    expect(Matriz.new(Array.new(2, Array.new(2, 1))).escalar(4).to_s).not_to eq(nil)
    expect(Matriz.new(Array.new(3, Array.new(3, 2))).escalar(2).to_s).to eq(Matriz.new(Array.new(3, Array.new(3, 4))).to_s)
  end

  it "Se debe poder hacer la traspuesta" do
    expect(Matriz.new(Array.new(3, Array.new(3) { |i| 2*i })).traspuesta.to_s).to eq("0 0 0 2 2 2 4 4 4")
    expect(Matriz.new(Array.new(3, Array.new(3) { |i| 2*i })).traspuesta.to_s).not_to eq(nil)
    expect(Matriz.new(Array.new(4, Array.new(4) { |i| 2*i })).traspuesta.to_s).to eq("0 0 0 0 2 2 2 2 4 4 4 4 6 6 6 6")
  end

end
