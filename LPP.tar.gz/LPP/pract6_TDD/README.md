·· Adahi Oval Afonso, Práctica 6 ··


1. Se crea la estructura de directorios
2. Se crean los archivos matrix_spec.rb, matrix.rb y el Rakefile

3. Se define la primera tarea de Rakefile y la primera prueba del spec y falla
4. Se define el método initialize y la prueba no falla

5. Se define la prueba de los getters y falla
6. Se definen los getters y la prueba no falla

7. Se crea la prueba de to_s y falla
8. Se crea el método to_s y no falla

9. Se crea la prueba de suma y falla
10. Se crea el método de suma y no falla

11. Se crea la prueba del método escalar y falla
12. Se crea el método escalar y no falla

13. Se crea la prueba de traspuesta y falla
14. Se crea el método traspuesta y no falla