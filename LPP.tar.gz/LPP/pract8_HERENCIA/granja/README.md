# Granja

Esta gema describe distintos ámbitos de una granja.

## Installation

Add this line to your application's Gemfile:

```ruby
gem 'granja'
```

And then execute:

    $ bundle install

Or install it yourself as:

    $ gem install granja

## Usage

Se pueden instanciar varias clases dentro del módulo de la Granja para describir los componentes.

## Development

· Se crea la clase Funcionalidades

· Se crea el atributo condicion

· Se crea el atributo cuidados

· Se crea el atributo reproduccion

· Se crea la clase Datos

· Se crea el atributo id

· Se crea el atributo name

· Se crea el atributo type

· Se crea el atributo desc

#### Práctica 8

· Se completa el apartado 1

· Se completa el apartado 2

· Se completa el apartado 3

· Se completa el apartado 4

## Contributing

Bug reports and pull requests are welcome on GitHub at https://github.com/ULL-ESIT-LPP-2122/granja-alu0101242071.
