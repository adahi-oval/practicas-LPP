RSpec.describe Granja do

  context "Representacion de los Datos de una Granja - Granja::Datos" do
    context "Atributos de la clase Datos" do
      
      it "Tiene un atributo para la identificación de la granja" do
        expect(Granja::Datos.new(1,"name","type","desc").id).to eq(1)
      end

      it "Tiene un atributo para el nombre de la granja" do
        expect(Granja::Datos.new(1,"name","type","desc").name).to eq("name")
      end

      it "Tiene un atributo para el tipo de la granja" do
        expect(Granja::Datos.new(1,"name","type","desc").type).to eq("type")
      end

      it "Tiene un atributo para la descripción de la granja" do
        expect(Granja::Datos.new(1,"name","type","desc").desc).to eq("desc")
      end

      it "Se obtiene una cadena con la información de la granja correctamente formateada" do
        expect(Granja::Datos.new(1,"name","type","desc").to_s).to eq("name:\n  ID: 1\n  Tipo: type\n  Descripción: desc")
      end

    end

    context "Herencia de la clase Datos" do
    
      it "Se espera que una instancia de la clase Datos sea un Datos" do
        expect(Granja::Datos.new(1,"name","type","desc").is_a?(Granja::Datos)).to be true
      end

      it "Se espera que una instancia de la clase Datos sea un objeto" do
        expect(Granja::Datos.new(1,"name","type","desc").is_a?(Object)).to be true
      end

      it "Se espera que una instancia de la clase Datos sea un objeto básico" do
        expect(Granja::Datos.new(1,"name","type","desc").is_a?(BasicObject)).to be true
      end

      it "No se espera que una instancia de la clase Datos sea una cadena" do
        expect(Granja::Datos.new(1,"name","type","desc").is_a?(String)).to be false
      end

      it "No se espera que una instancia de la clase Datos sea un numero" do
        expect(Granja::Datos.new(1,"name","type","desc").is_a?(Numeric)).to be false
      end

    end

  end

end