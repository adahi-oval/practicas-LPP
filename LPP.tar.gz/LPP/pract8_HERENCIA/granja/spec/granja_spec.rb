# frozen_string_literal: true
# @author Adahi Oval
# Añadido comentario
RSpec.describe Granja do
  
  context "Representacion de un Animal - Granja::Animal" do
    context "Atributos de la clase Animal" do
      
      it "Tiene una clase Granja::Animal" do
        expect(Granja::Animal).not_to be(nil)
      end

      it "Tiene un atributo para identificar al animal" do
        expect(Granja::Animal.new("id","age","sex","weight").id).not_to be(nil)
      end

      it "Tiene un atributo con la edad del animal en días" do
        expect(Granja::Animal.new("id","age","sex","weight").age).not_to be(nil)
      end

      it "Tiene un atributo con el sexo del animal" do
        expect(Granja::Animal.new("id","age","sex","weight").sex).not_to be(nil)
      end

      it "Tiene un atributo con el peso del animal" do
        expect(Granja::Animal.new("id","age","sex","weight").weight).not_to be(nil)
      end

      it "Se espera una cadena con la información del animal correctamente formateada" do
        expect(Granja::Animal.new("Manolo", "12", "Macho", "230").to_s).to eq("Manolo:\n  Edad: 12\n  Sexo: Macho\n  Peso: 230")
      end

    end

    context "Herencia de la clase Animal" do
      it "Se espera que una instancia de la clase Animal sea un Animal" do
        expect(Granja::Animal.new("id","age","sex","weight").is_a?(Granja::Animal)).to be(true)
      end

      it "Se espera que una instancia de la clase Animal sea un Objeto" do
        expect(Granja::Animal.new("id","age","sex","weight").is_a?(Object)).to be(true)
      end

      it "Se espera que una instancia de la clase Animal sea un Objeto básico" do
        expect(Granja::Animal.new("id","age","sex","weight").is_a?(BasicObject)).to be(true)
      end

      it "No se espera que una instancia de la clase Animal sea una cadena" do
        expect(Granja::Animal.new("id","age","sex","weight").is_a?(String)).to be(false)
      end

      it "No se espera que una instancia de la clase Animal sea un número" do
        expect(Granja::Animal.new("id","age","sex","weight").is_a?(Numeric)).to be(false)
      end

    end

    context "Métodos de contabilidad y comparación" do
      
      it "Se cuenta el número de animales" do
        expect(Granja::Animal.new("id","age","sex","weight").count).to eq(11)
      end

      it "Se compara animales por peso" do
        expect(Granja::Animal.new("id","age","sex",12)<=>Granja::Animal.new("id","age","sex",11)).to be 1
      end

      it "Se detecta si es menor" do
        expect(Granja::Animal.new("id","age","sex",12)<Granja::Animal.new("id","age","sex",11)).to be false
      end

      it "Se detecta si es mayor" do
        expect(Granja::Animal.new("id","age","sex",12)>Granja::Animal.new("id","age","sex",11)).to be true
      end

    end

  end

  context "Representación de un Ave - Granja::Ave" do
    context "Atributos de la clase Ave" do
      it "Tiene una clase Granja::Ave" do
        expect(Granja::Ave).not_to be(nil)
      end

      it "Tiene un atributo para el tipo de pico" do
        expect(Granja::Ave.new("id","age","sex","weight","beak","feet","move").beak).not_to be(nil)
      end

      it "Tiene un atributo para el tipo de pata" do
        expect(Granja::Ave.new("id","age","sex","weight","beak","feet","move").feet).not_to be(nil)
      end

      it "Tiene un atributo para el tipo de movilidad" do
        expect(Granja::Ave.new("id","age","sex","weight","beak","feet","move").move).not_to be(nil)
      end

      it "Se espera una cadena con la información del ave correctamente formateada" do
        expect(Granja::Ave.new("Manolo","12","Macho","230","grueso","palmeadas","nadadora").to_s).to eq("Manolo:\n  Edad: 12\n  Sexo: Macho\n  Peso: 230\n  Pico: grueso\n  Patas: palmeadas\n  Movilidad: nadadora")
      end

    end

    context "Herencia de la clase Ave" do
      it "Se espera que una instancia de la clase Ave sea un Ave" do
        expect(Granja::Ave.new("id","age","sex","weight","beak","feet","move").is_a?(Granja::Ave)).to be(true)
      end

      it "Se espera que una instancia de la clase Ave sea un Animal" do
        expect(Granja::Ave.new("id","age","sex","weight","beak","feet","move").is_a?(Granja::Animal)).to be(true)
      end

      it "Se espera que una instancia de la clase Ave sea un objeto" do
        expect(Granja::Ave.new("id","age","sex","weight","beak","feet","move").is_a?(Object)).to be(true)
      end

      it "Se espera que una instancia de la clase Ave sea un objeto básico" do
        expect(Granja::Ave.new("id","age","sex","weight","beak","feet","move").is_a?(BasicObject)).to be(true)
      end

      it "No se espera que una instancia de la clase Ave sea una cadena" do
        expect(Granja::Ave.new("id","age","sex","weight","beak","feet","move").is_a?(String)).to be(false)
      end

      it "No se espera que una instancia de la clase Ave sea un número" do
        expect(Granja::Ave.new("id","age","sex","weight","beak","feet","move").is_a?(Numeric)).to be(false)
      end

    end

    context "Métodos de contabilidad y comparación" do
      
      it "Las aves se incluyen en el contador" do
        expect(Granja::Ave.new("id","age","sex","weight","beak","feet","move").count).to eq(28)
      end

      it "Se compara aves por edad" do
        expect(Granja::Ave.new("id",23,"sex","weight","beak","feet","move")<=>Granja::Ave.new("id",22,"sex","weight","beak","feet","move")).to be 1
      end

      it "Si uno de ellos es un animal se compara por peso" do
        expect(Granja::Animal.new("id",23,"sex",12)<=>Granja::Ave.new("id",22,"sex",13,"beak","feet","move")).to be -1
      end

    end

  end

end
