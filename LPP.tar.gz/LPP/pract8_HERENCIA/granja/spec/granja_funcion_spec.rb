RSpec.describe Granja do
  
  context "Interfaz de las funcionalidades - Granja::Funcion" do
  
    context "Componentes del módulo Función" do
    
      it "Existe un módulo para almacenar las Funcionalidades" do
        expect(Granja::Funcion).not_to be nil
      end

      it "Existe una constante para representar las condiciones de vida de establo" do
        expect(Granja::Funcion::ESTABLO).not_to be nil
      end

      it "Existe una constante para representar las condiciones de vida de campo abierto" do
        expect(Granja::Funcion::CAMPO).not_to be nil
      end

      it "Existe un procedimiento para establecer los cuidados de los animales" do
        expect(Granja::Funcion::care).not_to be nil
      end

      it "Existe un procedimiento para establecer la reproducción de los animales" do
        expect(Granja::Funcion::repro).not_to be nil
      end
      
    end

    context "Herencia del módulo Función" do
      
      it "Se espera que sea un objeto de la clase Module" do
        expect(Granja::Funcion.is_a?(Module)).to be true
      end

      it "Se espera que sea un objeto" do
        expect(Granja::Funcion.is_a?(Object)).to be true
      end

      it "Se espera que sea un objeto basico" do
        expect(Granja::Funcion.is_a?(BasicObject)).to be true
      end

      it "No se espera que sea una instancia de la clase que representa una cadena" do
        expect(Granja::Funcion.is_a?(String)).to be false
      end

      it "No se espera que sea una instancia de la clase que representa un numero" do
        expect(Granja::Funcion.is_a?(Numeric)).to be false
      end

    end
    
  end

end
