require_relative "granja_animal.rb"

module Granja
  class Ave < Animal
    attr_reader :beak, :feet, :move

    def initialize(id,age,sex,weight,beak,feet,move)
      super(id,age,sex,weight)
      @beak = beak
      @feet = feet
      @move = move
    end

    def to_s
      s = super.to_s
      s << "\n  Pico: #{@beak}\n  Patas: #{@feet}\n  Movilidad: #{@move}"
    end

    def count
      @@number_of_animals
    end

    def <=>(other)
      return super<=>(other) unless other.is_a?(Ave)
      self.age <=> other.age
    end

  end
end