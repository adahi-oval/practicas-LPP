35: al poner "\t\n" irb lo interpreta de forma literal pero al poner '\t\n' irb lo convierte a sintaxis de ruby

36: %q hace que muestre el contenido de las {} en el output de forma no interpolada. %q{hello world\n} muestra el string de forma literal excepto por el caracter especial \n. lo mismo ocurre con %q{'a' 'b' 'c'}

37: %Q hace que se muestre el contenido de las {} en el output de forma interpolada. %Q{hello world\n} muestra el contenido de forma literal. %Q{"a" "b" "c"} muestra el contenido poniendo \ antes de cada ".

38: "--4--\ṇ--2--\n"

39: "--\#{a}--\n--\#{b}--\n"

40: s[0,2] = "he", s[-1,1] = "o", s[0,10] = "hello"

41: "hello world"

42: "..." 

43: "2 2 2"

44: es una enumeracion de los elementos separados por espacios

45: es una enumeracion de los elementos separados por espacios pero pone \ porque son caracteres especiales

46: es una enumeracion literal del contenido separado por espacios

47: [nil, nil, nil]

48: [0, 0, 0]

49: [[1, 2], [3, 4]]

50: [0, 2, 4]

51: ["b"], ["d", "e"], ["a", "b", "c"], ["a"], ["d", "e"]

52: ["A", "B", "c", "d", "e"], ["A", "B", "C", "D", "E"], [1, 2, 3, "A", "B", "C", "D", "E"], [3, "A", "B", "C", "D", "E"], [3, "A", "B", "C", "D", "Z"], [3, "A", "B", "C", nil]

53: [1, 2, 3, 4], [1, 2, 3, 4, 4, 5], [1, 2, 3, 4, 4, 5, [6, 7, 8]], error

54: ["a", "b", "c", "b", "a"], ["a", "a"]

55: [0, 0, 0, 0, 0, 0, 0, 0]

56: [1], [1, 2, 3], [1, 2, 3, [4, 5, 6]], [1, 2, 3, [4, 5, 6], 7, 8]

57: [1, 2, 3, 4, 5], [5, 4, 3, 2, 1], [2, 3, 4], [4, 3, 2]

58: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], [1, 2, 3, 4, 5, 6, 7, 8, 9], false, true, 1...10, error

59: true, true, true

60: TrueClass, FalseClass, hello => nil, => nil, (irb):12: warning: string literal in condition hello => nil

61: Symbol, false, true, Symbol, true, true

62: "Ruby", "", Rub => nil, RubJava => nil

63: "3 rubies"

64: [4, 5], 5, [1, 2, 3]

65: [:a, :b], [1, 2], {:a=>1, :b=>2, :c=>3}, {:b=>2, :c=>3}, {:a=>1}, {:a=>1}

66: asigna un hash vacío a "counts" y la otra asigna "{}" a counts

67: ["hello", "world", "hello", "LPP"]
