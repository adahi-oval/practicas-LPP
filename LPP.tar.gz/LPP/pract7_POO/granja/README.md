# Granja

Welcome to your new gem! In this directory, you'll find the files you need to be able to package up your Ruby library into a gem. Put your Ruby code in the file `lib/granja`. To experiment with that code, run `bin/console` for an interactive prompt.

TODO: Delete this and the text above, and describe your gem

## Installation

Add this line to your application's Gemfile:

```ruby
gem 'granja'
```

And then execute:

    $ bundle install

Or install it yourself as:

    $ gem install granja

## Usage

TODO: Write usage instructions here

## Development

· Se crea la clase Funcionalidades

· Se crea el atributo condicion

· Se crea el atributo cuidados

· Se crea el atributo reproduccion

· Se crea la clase Datos

· Se crea el atributo id

· Se crea el atributo name

· Se crea el atributo type

· Se crea el atributo desc

## Contributing

Bug reports and pull requests are welcome on GitHub at https://github.com/[USERNAME]/granja.
