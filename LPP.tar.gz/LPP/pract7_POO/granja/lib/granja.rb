# frozen_string_literal: true

require_relative "granja/version"

module Granja
  class Error < StandardError; end
  # @author Adahi Oval
  # Añadido comentario
  class Funcionalidades
    # Crea el objeto Funcionalidades
    # @param condicion,cuidados,reproduccion son los atributos que describen las funcionalidades
    def initialize(condicion,cuidados,reproduccion)
      @condicion = condicion
      @cuidados = cuidados
      @reproduccion = reproduccion
    end
  end

  # @author Adahi Oval
  class Datos
    # Crea el objeto Datos
    # @param id,name,type,desc son los atributos que describen a la granja
    def initialize(id,name,type,desc)
      @id = id
      @name = name
      @type = type
      @desc = desc
    end
  end

end
