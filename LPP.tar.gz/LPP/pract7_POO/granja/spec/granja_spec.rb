# frozen_string_literal: true
# @author Adahi Oval
# Añadido comentario
RSpec.describe Granja do
  it "Tiene un número de version X.Y.Z" do
    expect(Granja::VERSION).not_to be nil
  end
  
  describe Granja::Funcionalidades do
    
    it "Tiene una clase Granja::Funcionalidadess" do
      expect(Granja::Funcionalidades).not_to be(nil)
    end

    it "Tiene un atributo para las condiciones de los animales" do
      expect(Granja::Funcionalidades.new("condicion","cuidados","reproduccion")).not_to be nil
    end

    it "Tiene un atributo para los cuidados de los animales" do
      expect(Granja::Funcionalidades.new("condicion","cuidados","reproduccion")).not_to be nil
    end

    it "Tiene un atributo para la reproducción de los animales" do
      expect(Granja::Funcionalidades.new("condicion","cuidados","reproduccion")).not_to be nil
    end

  end

  describe Granja::Datos do
    it "Tiene una clase Granja::Datos" do
      expect(Granja::Datos).not_to be nil
    end

    it "Tiene un atributo para la identificacion de la granja" do
      expect(Granja::Datos.new("id","name","type","desc")).not_to be nil
    end

    it "Tiene un atributo para el nombre de la granja" do
      expect(Granja::Datos.new("id","name","type","desc")).not_to be nil
    end

    it "Tiene un atributo para el tipo de la granja" do
      expect(Granja::Datos.new("id","name","type","desc")).not_to be nil
    end

    it "Tiene un atributo para la descripción de la granja" do
      expect(Granja::Datos.new("id","name","type","desc")).not_to be nil
    end

  end

end
