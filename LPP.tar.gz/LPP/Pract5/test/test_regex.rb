require 'test/unit'
require 'lib/regex'

class TestRegex < Test::Unit::TestCase
  def setup
    @regex_a = Regex.new("a")
    @regex_b = Regex.new("b")
  end
  def test_simple
    #Comprobar getter exp
    assert_equal("hey", Regex.new("hey").exp)
    #Comprobar to_s
    assert_equal("hallo", Regex.new("hallo").to_s)
  end

  def test_concatenación
    #Comprobar que funciona la concatenación
    assert_equal("ab", @regex_a.conc(@regex_b).to_s)
  end

  def test_alternativa
    #Comprobar que funciona la alternativa
    assert_equal("a|b", @regex_a.alt(@regex_b).to_s)
  end

  def test_kleene
    #Comprobar el método kleene
    assert_equal("a*", @regex_a.kleene().to_s)
  end

  def test_general
    #Comprobar que todo funciona en conjunción
    assert_equal("aba|a*", @regex_a.conc(@regex_b.conc(@regex_a.alt(@regex_a.kleene()))).to_s)
  end

end