# Pract 05: Pruebas Unitarias

class Regex
    attr_reader :exp

    # Inicializador
    def initialize(exp)
        @exp = exp
    end

    def to_s
        return "#{exp}"
    end

    def conc(regex)
        Regex.new(self.to_s + regex.to_s)
    end

    def alt(regex)
        Regex.new(self.to_s + "|" + regex.to_s)
    end

    def kleene()
        Regex.new(self.to_s + '*')
    end

end