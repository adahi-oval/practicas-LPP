Práctica 5: Pruebas Unitarias

·Adahi Oval Afonso, alu0101242071·


· Desarrollo del método initialize
· Comprobación del método initialize y el getter de exp

· Desarrollo del método to_s
· Comprobación del método to_s

· Desarrollo del método conc
· Corrección de errores y comprobación del método conc

· Desarrollo del método alt
· Comprobación del método alt

· Desarrollo del método kleene
· Comprobación del método kleene

· Comprobación general en conjunción de las funcionalidades añadidas


